import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;

const ALLOWED_MODELS = new Set(["gemini-3.1-flash-image", "gemini-3-pro-image"]);
const ALLOWED_RATIOS = new Set(["1:1", "4:5", "3:4", "9:16", "16:9", "3:2", "2:3", "4:3", "5:4", "21:9"]);
const ALLOWED_SIZES = new Set(["1K", "2K", "4K"]);
const ALLOWED_KINDS = new Set(["model", "pose", "outfit", "scene", "previous"]);

type IncomingReference = { kind: string; name?: string; mimeType: string; data: string };

function jsonError(message: string, status: number) {
  return NextResponse.json({ error: message }, { status });
}

export async function POST(request: NextRequest) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return jsonError("A chave GEMINI_API_KEY ainda não foi configurada no servidor. Consulte o arquivo README.", 503);

  let body: { prompt?: string; negativePrompt?: string; model?: string; ratio?: string; resolution?: string; references?: IncomingReference[] };
  try {
    body = await request.json();
  } catch {
    return jsonError("O corpo da solicitação não contém JSON válido.", 400);
  }

  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  if (prompt.length < 5) return jsonError("Escreva um prompt com pelo menos 5 caracteres.", 400);
  if (prompt.length > 12000) return jsonError("O prompt ultrapassa o limite de 12.000 caracteres.", 400);

  const model = body.model && ALLOWED_MODELS.has(body.model) ? body.model : "gemini-3.1-flash-image";
  const ratio = body.ratio && ALLOWED_RATIOS.has(body.ratio) ? body.ratio : "4:5";
  let resolution = body.resolution && ALLOWED_SIZES.has(body.resolution) ? body.resolution : "1K";

  const references = Array.isArray(body.references) ? body.references : [];
  if (references.length > 12) return jsonError("Use no máximo 12 imagens de referência por geração.", 400);
  const maxMb = Number(process.env.MAX_REFERENCE_MB || 18);
  let totalBytes = 0;
  const parts: Array<{ text: string } | { inlineData: { data: string; mimeType: string } }> = [];
  const labels: Record<string, string> = {
    model: "IDENTIDADE DA MODELO — preserve o rosto, cabelo, aparência e características da referência",
    pose: "REFERÊNCIA DE POSE — use somente como guia de posição corporal, braços, pernas, mãos e ângulo",
    outfit: "REFERÊNCIA DE ROUPA — use como guia da peça, cor, corte, textura e acessórios",
    scene: "REFERÊNCIA DE CENÁRIO — use como guia de ambiente e atmosfera",
    previous: "IMAGEM ANTERIOR — use como base para a edição solicitada",
  };

  for (const ref of references) {
    if (!ref || !ALLOWED_KINDS.has(ref.kind) || typeof ref.data !== "string") continue;
    if (!["image/jpeg", "image/png", "image/webp"].includes(ref.mimeType)) continue;
    const base64 = ref.data.replace(/^data:[^;]+;base64,/, "");
    if (!/^[A-Za-z0-9+/]*={0,2}$/.test(base64)) continue;
    totalBytes += Math.floor(base64.length * 0.75);
    if (totalBytes > maxMb * 1024 * 1024) return jsonError(`As referências ultrapassam ${maxMb} MB. Reduza o tamanho dos arquivos.`, 413);
    parts.push({ text: `\n\n${labels[ref.kind]}${ref.name ? ` (${ref.name})` : ""}:` });
    parts.push({ inlineData: { data: base64, mimeType: ref.mimeType } });
  }

  const finalPrompt = [
    "Você é um sistema profissional de fotografia e edição de imagens.",
    "Crie uma única imagem visualmente coerente seguindo o pedido abaixo.",
    "Quando houver referências de identidade, mantenha a mesma pessoa com a maior fidelidade possível. Não misture a identidade com pessoas das referências de pose ou roupa.",
    "Use referências de pose, roupa e cenário somente para seus respectivos atributos. Priorize a instrução escrita em caso de conflito.",
    "Busque realismo fotográfico, anatomia plausível, mãos naturais, textura de pele sem aparência plástica, tecidos detalhados, luz consistente e composição profissional.",
    "Não adicione texto, marcas d'água ou elementos gráficos, a menos que sejam pedidos.",
    `PROMPT DO USUÁRIO:\n${prompt}`,
    body.negativePrompt?.trim() ? `\nELEMENTOS A EVITAR:\n${body.negativePrompt.trim()}` : "",
  ].filter(Boolean).join("\n\n");

  parts.unshift({ text: finalPrompt });
  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model,
      contents: [{ role: "user", parts }],
      config: {
        responseModalities: ["IMAGE"],
        responseFormat: { image: { aspectRatio: ratio, imageSize: resolution } },
      },
    });

    const responseParts = response.candidates?.flatMap(candidate => candidate.content?.parts ?? []) ?? [];
    const generated = responseParts.find(part => part.inlineData?.data && part.inlineData.mimeType);
    if (!generated?.inlineData?.data || !generated.inlineData.mimeType) {
      const textPart = responseParts.find(part => part.text)?.text;
      return jsonError(textPart || "O modelo não retornou uma imagem. Tente novamente com outra instrução ou configuração.", 502);
    }

    return NextResponse.json({
      image: `data:${generated.inlineData.mimeType};base64,${generated.inlineData.data}`,
      mimeType: generated.inlineData.mimeType,
      model,
      resolution,
      ratio,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erro desconhecido ao gerar imagem.";
    const safeMessage = message.includes("API key") || message.includes("PERMISSION_DENIED")
      ? "A API rejeitou a chave ou a permissão. Confira sua GEMINI_API_KEY e o faturamento no Google AI Studio."
      : message.includes("RESOURCE_EXHAUSTED") || message.includes("429")
        ? "O limite de uso da API foi atingido. Confira sua cota ou tente novamente mais tarde."
        : message.includes("SAFETY") || message.toLowerCase().includes("safety")
          ? "A solicitação foi bloqueada pelos filtros de segurança do provedor. Revise o conteúdo e as referências."
          : `Falha na geração: ${message.slice(0, 500)}`;
    return jsonError(safeMessage, 502);
  }
}
