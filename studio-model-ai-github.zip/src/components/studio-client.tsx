"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Aperture, ArrowDownToLine, ArrowLeft, ArrowRight, Bookmark, Check, ChevronDown,
  CircleHelp, Clapperboard, Clock3, CloudUpload, Copy, Download, Expand, Eye,
  FileImage, FolderOpen, ImagePlus, Images, Layers3, LoaderCircle, LockKeyhole,
  Menu, MessageSquareText, MoreHorizontal, Paintbrush, Plus, RefreshCw, Save,
  Settings2, ShieldCheck, SlidersHorizontal, Sparkles, Trash2, Upload, UserRound,
  WandSparkles, X, Zap,
} from "lucide-react";
import { deleteGalleryItem, deleteModel, getGallery, getModels, saveGalleryItem, saveModel } from "@/lib/db";
import type { GalleryItem, ImageReference, ModelProfile, RefKind } from "@/lib/types";

type Tab = "create" | "models" | "gallery" | "settings";

const MODEL_OPTIONS = [
  { id: "gemini-3.1-flash-image", name: "Nano Banana 2", note: "Equilíbrio entre qualidade e velocidade", tag: "RECOMENDADO" },
  { id: "gemini-3-pro-image", name: "Nano Banana Pro", note: "Trabalhos complexos e acabamento premium", tag: "PRO" },
];
const POSE_CATEGORIES = ["Todas", "Em pé", "Sentada", "Deitada", "Moda", "Casual", "Academia", "Sensual", "Cinematográfica"];
const POSES = [
  { id: "standing-front", name: "Em pé, de frente", category: "Em pé", glyph: "🧍", prompt: "em pé, de frente para a câmera, postura natural e elegante" },
  { id: "standing-side", name: "Em pé, de lado", category: "Em pé", glyph: "🚶", prompt: "em pé de perfil, corpo levemente voltado para a câmera" },
  { id: "standing-editorial", name: "Pose editorial", category: "Moda", glyph: "💃", prompt: "pose editorial de moda, peso do corpo em uma perna, postura confiante" },
  { id: "sitting-chair", name: "Sentada em cadeira", category: "Sentada", glyph: "🪑", prompt: "sentada em uma cadeira com postura natural e mãos relaxadas" },
  { id: "sitting-floor", name: "Sentada no chão", category: "Sentada", glyph: "🧘", prompt: "sentada no chão, pose descontraída e composição delicada" },
  { id: "sitting-side", name: "Sentada de lado", category: "Sentada", glyph: "🪑", prompt: "sentada de lado, rosto voltado suavemente para a câmera" },
  { id: "lying-side", name: "Deitada de lado", category: "Deitada", glyph: "🛏️", prompt: "deitada de lado, cabeça apoiada delicadamente em uma das mãos" },
  { id: "lying-back", name: "Deitada de costas", category: "Deitada", glyph: "🌙", prompt: "deitada de costas, pose relaxada e composição fotográfica elegante" },
  { id: "walking", name: "Caminhando", category: "Casual", glyph: "🚶‍♀️", prompt: "capturada caminhando, movimento natural e espontâneo" },
  { id: "look-back", name: "Olhar por cima do ombro", category: "Moda", glyph: "↩️", prompt: "corpo parcialmente de costas, olhando por cima do ombro para a câmera" },
  { id: "portrait", name: "Retrato aproximado", category: "Cinematográfica", glyph: "📸", prompt: "retrato aproximado, rosto em destaque e olhar direcionado à câmera" },
  { id: "relaxed", name: "Pose descontraída", category: "Casual", glyph: "☀️", prompt: "pose descontraída, ombros relaxados e expressão espontânea" },
  { id: "fitness", name: "Pose fitness", category: "Academia", glyph: "🏃‍♀️", prompt: "pose esportiva natural, postura atlética e confiante" },
  { id: "sensual-editorial", name: "Editorial sensual", category: "Sensual", glyph: "✨", prompt: "pose editorial sensual e sofisticada, elegante e não explícita" },
];
const OUTFIT_CATEGORIES = ["Vestido", "Saia", "Shorts", "Calça", "Camiseta", "Blusa", "Camisa", "Jaqueta", "Academia", "Praia", "Elegante", "Casual", "Fashion", "Noturna", "Personalizada"];
const SCENES = ["Estúdio fotográfico", "Quarto", "Sala moderna", "Praia", "Piscina", "Natureza", "Rua urbana", "Ambiente luxuoso", "Cenário cinematográfico", "Personalizado"];
const RATIOS = ["1:1", "4:5", "3:4", "9:16", "16:9", "3:2", "2:3", "4:3"];

function uid() { return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`; }
function formatDate(value: number) { return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" }).format(value); }

async function compressImage(file: File): Promise<{ dataUrl: string; mimeType: string }> {
  if (!file.type.startsWith("image/")) throw new Error("Escolha um arquivo de imagem.");
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) throw new Error("Use JPG, PNG ou WebP.");
  if (file.size > 16 * 1024 * 1024) throw new Error("O arquivo deve ter até 16 MB.");
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Não foi possível processar a imagem.");
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error("Falha ao comprimir imagem.")), "image/jpeg", 0.88));
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("Falha ao ler imagem."));
    reader.onerror = () => reject(new Error("Falha ao ler imagem."));
    reader.readAsDataURL(blob);
  });
  return { dataUrl, mimeType: "image/jpeg" };
}

function SectionLabel({ children, hint }: { children: React.ReactNode; hint?: string }) {
  return <div className="section-label"><span>{children}</span>{hint && <small>{hint}</small>}</div>;
}

function UploadCard({ title, subtitle, reference, onUpload, onRemove, compact = false }: {
  title: string; subtitle: string; reference?: ImageReference; onUpload: (file: File) => void; onRemove?: () => void; compact?: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  return <div className={`upload-card ${compact ? "compact" : ""} ${reference ? "has-image" : ""}`}>
    <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={e => { const file = e.target.files?.[0]; if (file) onUpload(file); e.currentTarget.value = ""; }} />
    {reference ? <>
      <img src={reference.dataUrl} alt={reference.name} />
      <div className="upload-overlay"><span>{reference.name}</span><div className="upload-actions"><button type="button" title="Trocar imagem" onClick={() => inputRef.current?.click()}><RefreshCw size={15} /></button>{onRemove && <button type="button" title="Remover imagem" onClick={onRemove}><Trash2 size={15} /></button>}</div></div>
    </> : <button type="button" className="upload-empty" onClick={() => inputRef.current?.click()}>
      <span className="upload-icon"><CloudUpload size={19} /></span><strong>{title}</strong><small>{subtitle}</small>
    </button>}
  </div>;
}

export default function StudioClient() {
  const [tab, setTab] = useState<Tab>("create");
  const [models, setModels] = useState<ModelProfile[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [selectedModelId, setSelectedModelId] = useState("");
  const [modelName, setModelName] = useState("Minha modelo");
  const [modelDescription, setModelDescription] = useState("");
  const [modelRefs, setModelRefs] = useState<ImageReference[]>([]);
  const [poseRef, setPoseRef] = useState<ImageReference | undefined>();
  const [outfitRef, setOutfitRef] = useState<ImageReference | undefined>();
  const [sceneRef, setSceneRef] = useState<ImageReference | undefined>();
  const [poseCategory, setPoseCategory] = useState("Todas");
  const [selectedPose, setSelectedPose] = useState(POSES[0]);
  const [outfitCategory, setOutfitCategory] = useState("Vestido");
  const [outfitDescription, setOutfitDescription] = useState("vestido preto elegante, tecido de boa qualidade");
  const [outfitColor, setOutfitColor] = useState("Preto");
  const [scene, setScene] = useState("Estúdio fotográfico");
  const [sceneDescription, setSceneDescription] = useState("");
  const [lighting, setLighting] = useState("Luz suave profissional");
  const [style, setStyle] = useState("Fotografia hiper-realista");
  const [framing, setFraming] = useState("Corpo inteiro");
  const [cameraAngle, setCameraAngle] = useState("Na altura dos olhos");
  const [depth, setDepth] = useState("Profundidade de campo natural");
  const [prompt, setPrompt] = useState("Crie uma fotografia extremamente realista da modelo cadastrada, mantendo sua identidade visual. Ela deve estar em uma composição editorial elegante, com expressão natural, anatomia correta, textura de pele realista e iluminação profissional.");
  const [negativePrompt, setNegativePrompt] = useState("rosto diferente, identidade alterada, mãos deformadas, dedos extras, anatomia incorreta, pele plástica, baixa resolução, borrões, artefatos");
  const [providerModel, setProviderModel] = useState("gemini-3.1-flash-image");
  const [ratio, setRatio] = useState("4:5");
  const [resolution, setResolution] = useState("1K");
  const [generatedImage, setGeneratedImage] = useState("");
  const [generatedMeta, setGeneratedMeta] = useState<{ mimeType: string; model: string } | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [galleryFilter, setGalleryFilter] = useState("Todas");

  useEffect(() => {
    Promise.all([getModels(), getGallery()]).then(([savedModels, savedGallery]) => {
      const ordered = savedModels.sort((a, b) => b.updatedAt - a.updatedAt);
      setModels(ordered);
      setGallery(savedGallery.sort((a, b) => b.createdAt - a.createdAt));
      if (ordered[0]) {
        setSelectedModelId(ordered[0].id);
        setModelName(ordered[0].name);
        setModelDescription(ordered[0].description);
        setModelRefs(ordered[0].references);
      }
    }).catch(() => setError("Não foi possível abrir o armazenamento deste navegador."))
      .finally(() => setIsLoading(false));
  }, []);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(""), 3200);
    return () => window.clearTimeout(timer);
  }, [notice]);

  const currentModel = useMemo(() => models.find(m => m.id === selectedModelId), [models, selectedModelId]);
  const filteredPoses = useMemo(() => POSES.filter(p => poseCategory === "Todas" || p.category === poseCategory), [poseCategory]);
  const filteredGallery = useMemo(() => galleryFilter === "Todas" ? gallery : gallery.filter(item => item.modelId === galleryFilter), [gallery, galleryFilter]);

  const addReference = useCallback(async (file: File, kind: "model" | "pose" | "outfit" | "scene") => {
    try {
      const processed = await compressImage(file);
      const ref: ImageReference = { id: uid(), kind, name: file.name || "Referência", ...processed };
      if (kind === "model") setModelRefs(prev => [...prev, ref].slice(-5));
      if (kind === "pose") setPoseRef(ref);
      if (kind === "outfit") setOutfitRef(ref);
      if (kind === "scene") setSceneRef(ref);
      setError("");
    } catch (e) { setError(e instanceof Error ? e.message : "Não foi possível adicionar a imagem."); }
  }, []);

  const saveCurrentModel = async () => {
    const name = modelName.trim() || "Modelo sem nome";
    if (!modelRefs.length) { setError("Adicione pelo menos uma foto de referência da modelo."); return; }
    try {
      const now = Date.now();
      const profile: ModelProfile = {
        id: selectedModelId || uid(), name, description: modelDescription.trim(), references: modelRefs,
        createdAt: currentModel?.createdAt ?? now, updatedAt: now,
      };
      await saveModel(profile);
      const next = [profile, ...models.filter(m => m.id !== profile.id)].sort((a, b) => b.updatedAt - a.updatedAt);
      setModels(next); setSelectedModelId(profile.id); setModelName(name); setNotice("Modelo salva neste dispositivo."); setError("");
    } catch { setError("Não foi possível salvar. O armazenamento do navegador pode estar cheio."); }
  };

  const selectModel = (id: string) => {
    const found = models.find(m => m.id === id);
    if (!found) { setSelectedModelId(""); setModelName("Minha modelo"); setModelDescription(""); setModelRefs([]); return; }
    setSelectedModelId(id); setModelName(found.name); setModelDescription(found.description); setModelRefs(found.references);
  };

  const removeModel = async (id: string) => {
    if (!window.confirm("Excluir este perfil e suas referências salvas neste aparelho?")) return;
    await deleteModel(id);
    const next = models.filter(m => m.id !== id); setModels(next);
    if (selectedModelId === id) selectModel(next[0]?.id ?? "");
    setNotice("Perfil excluído.");
  };

  const buildPrompt = () => {
    const sections = [
      `PERSONAGEM: ${modelName}. ${modelDescription}`,
      `POSE: ${selectedPose.prompt}.`,
      `ROUPA: ${outfitDescription || outfitCategory}; cor ${outfitColor}.`,
      `CENÁRIO: ${scene}${sceneDescription ? `, ${sceneDescription}` : ""}.`,
      `ESTILO: ${style}. ILUMINAÇÃO: ${lighting}. ENQUADRAMENTO: ${framing}. ÂNGULO: ${cameraAngle}. FOCO: ${depth}.`,
      `DIREÇÃO CRIATIVA: ${prompt}`,
    ].filter(Boolean);
    setPrompt(sections.join("\n\n"));
    setNotice("Prompt composto com as suas escolhas. Revise antes de gerar.");
  };

  const generate = async (variation = false) => {
    if (!prompt.trim()) { setError("Escreva uma descrição para a imagem."); return; }
    if (!modelRefs.length) { setError("Cadastre ou adicione uma foto da modelo na seção Minha modelo."); return; }
    setIsGenerating(true); setError(""); setNotice("");
    try {
      const profileId = selectedModelId || uid();
      const now = Date.now();
      const profile: ModelProfile = { id: profileId, name: modelName.trim() || "Minha modelo", description: modelDescription.trim(), references: modelRefs, createdAt: currentModel?.createdAt ?? now, updatedAt: now };
      await saveModel(profile);
      setSelectedModelId(profileId);
      setModels(prev => [profile, ...prev.filter(m => m.id !== profileId)].sort((a, b) => b.updatedAt - a.updatedAt));
      const references = [
        ...modelRefs.map(r => ({ kind: "model", name: r.name, mimeType: r.mimeType, data: r.dataUrl })),
        ...(poseRef ? [{ kind: "pose", name: poseRef.name, mimeType: poseRef.mimeType, data: poseRef.dataUrl }] : []),
        ...(outfitRef ? [{ kind: "outfit", name: outfitRef.name, mimeType: outfitRef.mimeType, data: outfitRef.dataUrl }] : []),
        ...(sceneRef ? [{ kind: "scene", name: sceneRef.name, mimeType: sceneRef.mimeType, data: sceneRef.dataUrl }] : []),
        ...(variation && generatedImage ? [{ kind: "previous", name: "Imagem anterior", mimeType: generatedMeta?.mimeType || "image/jpeg", data: generatedImage }] : []),
      ];
      const response = await fetch("/api/generate", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, negativePrompt, model: providerModel, ratio, resolution, references }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || `Erro HTTP ${response.status}`);
      setGeneratedImage(result.image); setGeneratedMeta({ mimeType: result.mimeType, model: result.model });
      setNotice("Imagem gerada com sucesso. Salve na galeria para mantê-la neste aparelho.");
    } catch (e) { setError(e instanceof Error ? e.message : "Não foi possível gerar a imagem."); }
    finally { setIsGenerating(false); }
  };

  const saveGenerated = async () => {
    if (!generatedImage || !generatedMeta) return;
    const item: GalleryItem = {
      id: uid(), image: generatedImage, mimeType: generatedMeta.mimeType, prompt,
      modelName, modelId: selectedModelId, providerModel: generatedMeta.model,
      createdAt: Date.now(), ratio, resolution,
    };
    try {
      await saveGalleryItem(item); setGallery(prev => [item, ...prev]); setNotice("Imagem salva na sua galeria local.");
    } catch { setError("Não foi possível salvar: o armazenamento do navegador pode estar cheio. Exclua imagens antigas ou reduza as referências."); }
  };

  const deleteImage = async (id: string) => {
    if (!window.confirm("Excluir esta imagem da galeria?")) return;
    await deleteGalleryItem(id); setGallery(prev => prev.filter(item => item.id !== id));
  };

  const loadGalleryImage = (item: GalleryItem) => {
    setGeneratedImage(item.image); setGeneratedMeta({ mimeType: item.mimeType, model: item.providerModel });
    setPrompt(item.prompt); setProviderModel(item.providerModel); setRatio(item.ratio); setResolution(item.resolution);
    selectModel(item.modelId); setTab("create"); setNotice("Imagem carregada para edição. Use Variação / editar para enviá-la como referência.");
  };

  const downloadImage = () => {
    if (!generatedImage) return;
    const a = document.createElement("a"); a.href = generatedImage; a.download = `studio-model-${Date.now()}.${generatedMeta?.mimeType === "image/png" ? "png" : "jpg"}`; a.click();
  };

  const navItems: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "create", label: "Criar imagem", icon: <WandSparkles size={18} /> },
    { id: "models", label: "Minhas modelos", icon: <UserRound size={18} /> },
    { id: "gallery", label: "Galeria", icon: <Images size={18} /> },
    { id: "settings", label: "Configurações", icon: <Settings2 size={18} /> },
  ];

  return <main className="app-shell">
    <aside className={`sidebar ${menuOpen ? "mobile-open" : ""}`}>
      <div className="brand"><div className="brand-mark"><Aperture size={21} /></div><div><strong>STUDIO <span>MODEL</span></strong><small>AI CREATIVE LAB</small></div><button className="mobile-close" onClick={() => setMenuOpen(false)} aria-label="Fechar menu"><X size={18} /></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav className="side-nav">{navItems.map(item => <button key={item.id} className={tab === item.id ? "active" : ""} onClick={() => { setTab(item.id); setMenuOpen(false); }}>
        {item.icon}<span>{item.label}</span>{item.id === "gallery" && gallery.length > 0 && <small>{gallery.length}</small>}
      </button>)}</nav>
      <div className="sidebar-bottom"><div className="secure-card"><div className="secure-icon"><ShieldCheck size={17} /></div><div><strong>Seus arquivos são privados</strong><small>Perfis e galeria ficam neste aparelho.</small></div></div><div className="sidebar-version">STUDIO MODEL AI <span>v1.0</span></div></div>
    </aside>
    {menuOpen && <button className="mobile-backdrop" onClick={() => setMenuOpen(false)} aria-label="Fechar menu" />}

    <section className="main-area">
      <header className="topbar"><div className="topbar-left"><button className="mobile-menu" onClick={() => setMenuOpen(true)} aria-label="Abrir menu"><Menu size={20} /></button><div className="breadcrumbs">Workspace <span>/</span> <strong>{navItems.find(n => n.id === tab)?.label}</strong></div></div><div className="topbar-right"><span className="local-indicator"><i /> ARMAZENAMENTO LOCAL</span><div className="avatar">SM</div></div></header>

      {notice && <div className="toast success"><Check size={16} />{notice}<button onClick={() => setNotice("")}><X size={14} /></button></div>}
      {error && <div className="toast error"><CircleHelp size={16} />{error}<button onClick={() => setError("")}><X size={14} /></button></div>}

      {tab === "create" && <div className="page-content">
        <div className="page-heading"><div><div className="eyebrow"><Sparkles size={13} /> ESTÚDIO DE CRIAÇÃO</div><h1>Crie imagens <span>extraordinárias.</span></h1><p>Escolha sua modelo, defina cada detalhe e transforme sua ideia em fotografia.</p></div><div className="heading-chip"><Zap size={15} /> IA GENERATIVA</div></div>
        <div className="studio-grid">
          <div className="editor-column">
            <section className="panel model-panel"><div className="panel-heading"><div className="panel-title"><span className="step-number">01</span><div><h2>Minha modelo</h2><p>Escolha uma personagem ou cadastre uma nova.</p></div></div><button className="text-button" onClick={() => setTab("models")}>Gerenciar <ArrowRight size={14} /></button></div>
              <div className="model-select-row"><div className="select-wrap"><UserRound size={16} /><select value={selectedModelId} onChange={e => selectModel(e.target.value)}><option value="">Selecione uma modelo cadastrada</option>{models.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}</select><ChevronDown size={15} /></div><button className="icon-button" title="Nova modelo" onClick={() => { selectModel(""); setTab("models"); }}><Plus size={17} /></button></div>
              {modelRefs.length ? <div className="reference-strip">{modelRefs.map(ref => <div className="reference-thumb" key={ref.id}><img src={ref.dataUrl} alt={ref.name} /><button onClick={() => setModelRefs(prev => prev.filter(r => r.id !== ref.id))} title="Remover"><X size={12} /></button></div>)}<button className="add-reference" onClick={() => document.getElementById("quick-model-upload")?.click()}><Plus size={18} /><span>Adicionar</span></button></div> : <div className="empty-model"><div className="empty-model-icon"><UserRound size={21} /></div><div><strong>Nenhuma modelo selecionada</strong><span>Cadastre fotos de referência para manter a identidade da personagem.</span></div><button onClick={() => setTab("models")}>Cadastrar modelo <ArrowRight size={14} /></button></div>}
              <input id="quick-model-upload" type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={e => { const file = e.target.files?.[0]; if (file) addReference(file, "model"); e.currentTarget.value = ""; }} />
            </section>

            <section className="panel"><div className="panel-heading"><div className="panel-title"><span className="step-number">02</span><div><h2>Pose da fotografia</h2><p>Selecione uma pose ou envie uma referência.</p></div></div></div>
              <div className="category-row">{POSE_CATEGORIES.map(cat => <button key={cat} className={poseCategory === cat ? "selected" : ""} onClick={() => setPoseCategory(cat)}>{cat}</button>)}</div>
              <div className="pose-grid">{filteredPoses.map(pose => <button key={pose.id} className={`pose-card ${selectedPose.id === pose.id ? "selected" : ""}`} onClick={() => setSelectedPose(pose)}><span className="pose-glyph">{pose.glyph}</span><span className="pose-name">{pose.name}</span>{selectedPose.id === pose.id && <span className="selected-check"><Check size={11} /></span>}</button>)}</div>
              <div className="reference-upload-line"><UploadCard compact title="Enviar pose" subtitle="JPG, PNG ou WebP" reference={poseRef} onUpload={f => addReference(f, "pose")} onRemove={() => setPoseRef(undefined)} /><div><strong>Pose personalizada</strong><p>Use uma foto como guia de posição corporal. A identidade da modelo será enviada separadamente.</p></div></div>
            </section>

            <section className="panel"><div className="panel-heading"><div className="panel-title"><span className="step-number">03</span><div><h2>Guarda-roupa</h2><p>Defina a roupa que a modelo vai vestir.</p></div></div></div>
              <div className="category-row wardrobe-row">{OUTFIT_CATEGORIES.map(cat => <button key={cat} className={outfitCategory === cat ? "selected" : ""} onClick={() => setOutfitCategory(cat)}>{cat}</button>)}</div>
              <div className="field-grid two"><label className="field"><span>Descrição da roupa</span><input value={outfitDescription} onChange={e => setOutfitDescription(e.target.value)} placeholder="Ex.: vestido longo de cetim..." /></label><label className="field"><span>Cor predominante</span><select value={outfitColor} onChange={e => setOutfitColor(e.target.value)}>{["Preto", "Branco", "Vermelho", "Azul", "Rosa", "Verde", "Bege", "Marrom", "Cinza", "Dourado", "Prata", "Multicolorido"].map(c => <option key={c}>{c}</option>)}</select></label></div>
              <div className="reference-upload-line"><UploadCard compact title="Enviar roupa" subtitle="Foto da peça" reference={outfitRef} onUpload={f => addReference(f, "outfit")} onRemove={() => setOutfitRef(undefined)} /><div><strong>Referência de vestuário</strong><p>Envie uma foto da peça para orientar cor, corte, tecido e detalhes.</p></div></div>
            </section>

            <section className="panel"><div className="panel-heading"><div className="panel-title"><span className="step-number">04</span><div><h2>Cenário & fotografia</h2><p>Monte a atmosfera da sua imagem.</p></div></div></div>
              <div className="field-grid two"><label className="field"><span>Ambiente</span><select value={scene} onChange={e => setScene(e.target.value)}>{SCENES.map(s => <option key={s}>{s}</option>)}</select></label><label className="field"><span>Iluminação</span><select value={lighting} onChange={e => setLighting(e.target.value)}>{["Luz suave profissional", "Luz natural de janela", "Luz dourada de fim de tarde", "Luz dramática cinematográfica", "Flash de estúdio", "Luz difusa editorial", "Neon colorido"].map(s => <option key={s}>{s}</option>)}</select></label>
                <label className="field"><span>Estilo fotográfico</span><select value={style} onChange={e => setStyle(e.target.value)}>{["Fotografia hiper-realista", "Editorial de moda", "Retrato profissional", "Fotografia cinematográfica", "Lifestyle natural", "Campanha publicitária", "Fotografia analógica"].map(s => <option key={s}>{s}</option>)}</select></label><label className="field"><span>Enquadramento</span><select value={framing} onChange={e => setFraming(e.target.value)}>{["Corpo inteiro", "Plano americano", "Plano médio", "Close-up", "Retrato de rosto", "Detalhe de composição"].map(s => <option key={s}>{s}</option>)}</select></label>
                <label className="field"><span>Ângulo da câmera</span><select value={cameraAngle} onChange={e => setCameraAngle(e.target.value)}>{["Na altura dos olhos", "Ângulo levemente alto", "Ângulo levemente baixo", "Vista lateral", "Vista de cima", "Perspectiva frontal"].map(s => <option key={s}>{s}</option>)}</select></label><label className="field"><span>Profundidade de campo</span><select value={depth} onChange={e => setDepth(e.target.value)}>{["Profundidade de campo natural", "Fundo desfocado (bokeh)", "Tudo em foco", "Desfoque cinematográfico"].map(s => <option key={s}>{s}</option>)}</select></label></div>
              <label className="field scene-description"><span>Detalhes do cenário <small>OPCIONAL</small></span><input value={sceneDescription} onChange={e => setSceneDescription(e.target.value)} placeholder="Ex.: quarto minimalista, tons neutros e janela ampla" /></label>
              <div className="reference-upload-line"><UploadCard compact title="Enviar cenário" subtitle="Referência de ambiente" reference={sceneRef} onUpload={f => addReference(f, "scene")} onRemove={() => setSceneRef(undefined)} /><div><strong>Referência de ambiente</strong><p>Adicione uma imagem para inspirar o local e a direção de arte.</p></div></div>
            </section>

            <section className="panel prompt-panel"><div className="panel-heading"><div className="panel-title"><span className="step-number">05</span><div><h2>Seu prompt</h2><p>Descreva a imagem com todos os detalhes que desejar.</p></div></div><button className="text-button" onClick={buildPrompt}><WandSparkles size={14} /> Compor prompt</button></div>
              <label className="field"><span>DESCREVA A IMAGEM QUE DESEJA CRIAR</span><textarea className="prompt-input" value={prompt} onChange={e => setPrompt(e.target.value)} rows={7} placeholder="Descreva a pose, expressão, ambiente, composição, detalhes de roupa..." /></label>
              <label className="field negative-field"><span>ELEMENTOS A EVITAR <small>OPCIONAL</small></span><textarea value={negativePrompt} onChange={e => setNegativePrompt(e.target.value)} rows={2} placeholder="Ex.: dedos extras, rosto distorcido, baixa resolução..." /></label>
              <div className="prompt-tip"><Sparkles size={15} /><span>Dica: clique em <b>Compor prompt</b> para combinar as seleções automaticamente. Você pode editar o texto gerado antes de criar.</span></div>
            </section>
          </div>

          <aside className="preview-column">
            <section className="panel preview-panel"><div className="preview-header"><div><span className="preview-overline">LIVE PREVIEW</span><h2>Resultado</h2></div><span className="preview-status"><i /> {isGenerating ? "GERANDO" : generatedImage ? "CONCLUÍDO" : "AGUARDANDO"}</span></div>
              <div className={`preview-canvas ratio-${ratio.replace(":", "-")}`}>
                {generatedImage ? <img src={generatedImage} alt="Imagem gerada pela IA" /> : <div className="preview-empty"><div className="preview-orbit orbit-one" /><div className="preview-orbit orbit-two" /><div className="preview-empty-icon"><Aperture size={30} /></div><strong>Sua próxima criação começa aqui</strong><span>Configure sua modelo e pressione gerar imagem.</span></div>}
                {isGenerating && <div className="generating-overlay"><div className="generating-animation"><Sparkles size={25} /></div><strong>Criando sua imagem</strong><span>O modelo está trabalhando nos detalhes...</span><div className="progress-track"><i /></div></div>}
              </div>
              <div className="preview-details"><div><span>MODELO IA</span><strong>{MODEL_OPTIONS.find(m => m.id === providerModel)?.name}</strong></div><div><span>PROPORÇÃO</span><strong>{ratio}</strong></div><div><span>RESOLUÇÃO</span><strong>{resolution}</strong></div></div>
              <div className="generation-options"><label className="field"><span>Motor de IA</span><select value={providerModel} onChange={e => { setProviderModel(e.target.value);  }}>{MODEL_OPTIONS.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}</select></label><div className="field-grid two"><label className="field"><span>Proporção</span><select value={ratio} onChange={e => setRatio(e.target.value)}>{RATIOS.map(r => <option key={r}>{r}</option>)}</select></label><label className="field"><span>Tamanho</span><select value={resolution} onChange={e => setResolution(e.target.value)}>{["1K", "2K", "4K"].map(r => <option key={r}>{r}</option>)}</select></label></div></div>
              <button className="generate-button" disabled={isGenerating || isLoading} onClick={() => generate(false)}>{isGenerating ? <><LoaderCircle size={18} className="spin" /> GERANDO IMAGEM...</> : <><Sparkles size={18} /> GERAR IMAGEM <ArrowRight size={17} /></>}</button>
              <div className="generate-footnote"><LockKeyhole size={12} /> A chave da API permanece protegida no servidor.</div>
              {generatedImage && <div className="result-actions"><button onClick={downloadImage}><Download size={15} /> Baixar</button><button onClick={saveGenerated}><Bookmark size={15} /> Salvar</button><button onClick={() => generate(true)} disabled={isGenerating}><RefreshCw size={15} /> Variação / editar</button></div>}
            </section>
            <section className="panel quick-summary"><div className="panel-heading"><div className="panel-title"><div className="summary-icon"><SlidersHorizontal size={16} /></div><div><h2>Resumo da criação</h2><p>Referências enviadas ao modelo.</p></div></div></div>
              <div className="summary-row"><span>Identidade</span><strong>{modelRefs.length} foto(s)</strong></div><div className="summary-row"><span>Pose</span><strong>{poseRef ? "Referência enviada" : selectedPose.name}</strong></div><div className="summary-row"><span>Roupa</span><strong>{outfitRef ? "Referência enviada" : outfitCategory}</strong></div><div className="summary-row"><span>Cenário</span><strong>{sceneRef ? "Referência enviada" : scene}</strong></div>
            </section>
            <section className="help-card"><div className="help-card-icon"><CircleHelp size={17} /></div><div><strong>Como melhorar a fidelidade?</strong><p>Use fotos nítidas da mesma modelo, com rosto visível e ângulos variados. A IA tenta preservar a identidade, mas o resultado pode variar.</p></div></section>
          </aside>
        </div>
      </div>}

      {tab === "models" && <div className="page-content secondary-page"><div className="page-heading"><div><div className="eyebrow"><UserRound size={13} /> BIBLIOTECA DE PERSONAGENS</div><h1>Minhas <span>modelos.</span></h1><p>Cadastre referências e reutilize a identidade visual das suas personagens.</p></div><button className="primary-small" onClick={() => { setSelectedModelId(""); setModelName("Nova modelo"); setModelDescription(""); setModelRefs([]); }}><Plus size={16} /> Nova modelo</button></div>
        <div className="models-layout"><section className="panel model-form"><div className="panel-heading"><div className="panel-title"><div className="summary-icon"><UserRound size={17} /></div><div><h2>{selectedModelId ? "Editar perfil" : "Cadastrar modelo"}</h2><p>As fotos são armazenadas localmente neste navegador.</p></div></div></div>
          <label className="field"><span>Nome da modelo</span><input value={modelName} onChange={e => setModelName(e.target.value)} placeholder="Ex.: Modelo editorial 01" /></label><label className="field"><span>Descrição visual <small>OPCIONAL</small></span><textarea rows={3} value={modelDescription} onChange={e => setModelDescription(e.target.value)} placeholder="Ex.: cabelo preto longo com franja reta, pele clara..." /></label>
          <SectionLabel hint="ATÉ 5 FOTOS">Referências de identidade</SectionLabel><div className="model-reference-grid">{modelRefs.map(ref => <div className="model-reference" key={ref.id}><img src={ref.dataUrl} alt={ref.name} /><button onClick={() => setModelRefs(prev => prev.filter(r => r.id !== ref.id))}><X size={14} /></button><span>{ref.name}</span></div>)}{modelRefs.length < 5 && <UploadCard title="Adicionar foto" subtitle="Rosto e aparência" onUpload={f => addReference(f, "model")} />}</div>
          <div className="form-actions"><button className="primary-button" onClick={saveCurrentModel}><Save size={16} /> Salvar modelo</button><button className="secondary-button" onClick={() => setTab("create")}>Voltar ao estúdio</button></div>
        </section><section className="panel saved-models"><div className="panel-heading"><div><h2>Perfis salvos</h2><p>{models.length} modelo(s) neste aparelho.</p></div></div>
          {models.length ? <div className="saved-model-list">{models.map(model => <div className={`saved-model-item ${selectedModelId === model.id ? "active" : ""}`} key={model.id}><img src={model.references[0]?.dataUrl} alt={model.name} /><div className="saved-model-info"><strong>{model.name}</strong><span>{model.references.length} referência(s) · atualizado {formatDate(model.updatedAt)}</span></div><button className="subtle-action" onClick={() => { selectModel(model.id); setNotice("Perfil carregado no editor."); }}><Eye size={15} /> Abrir</button><button className="danger-icon" onClick={() => removeModel(model.id)} title="Excluir perfil"><Trash2 size={15} /></button></div>)}</div> : <div className="empty-state"><UserRound size={28} /><strong>Nenhum perfil salvo ainda</strong><span>Adicione fotos e salve sua primeira modelo.</span></div>}
        </section></div>
      </div>}

      {tab === "gallery" && <div className="page-content secondary-page"><div className="page-heading"><div><div className="eyebrow"><Images size={13} /> SUAS CRIAÇÕES</div><h1>Sua <span>galeria.</span></h1><p>Imagens geradas e salvas neste dispositivo.</p></div><div className="gallery-count"><strong>{gallery.length}</strong><span>IMAGENS SALVAS</span></div></div>
        <div className="gallery-toolbar"><div className="gallery-filter"><FolderOpen size={16} /><select value={galleryFilter} onChange={e => setGalleryFilter(e.target.value)}><option value="Todas">Todas as modelos</option>{models.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}</select><ChevronDown size={14} /></div><span><Clock3 size={14} /> Mais recentes primeiro</span></div>
        {filteredGallery.length ? <div className="gallery-grid">{filteredGallery.map(item => <article className="gallery-card" key={item.id}><button className="gallery-image" onClick={() => loadGalleryImage(item)}><img src={item.image} alt={`Criação de ${item.modelName}`} /><span className="gallery-view"><Expand size={17} /> Abrir para editar</span></button><div className="gallery-card-info"><div><strong>{item.modelName || "Modelo"}</strong><span>{formatDate(item.createdAt)} · {item.ratio} · {item.resolution}</span></div><button className="danger-icon" onClick={() => deleteImage(item.id)} title="Excluir imagem"><Trash2 size={15} /></button></div><p>{item.prompt.slice(0, 110)}{item.prompt.length > 110 ? "…" : ""}</p></article>)}</div> : <div className="empty-gallery"><div className="empty-model-icon"><Images size={23} /></div><h2>Sua galeria está esperando sua primeira criação.</h2><p>Gere uma imagem e clique em Salvar para ela aparecer aqui.</p><button className="primary-button" onClick={() => setTab("create")}><Sparkles size={16} /> Criar primeira imagem</button></div>}
      </div>}

      {tab === "settings" && <div className="page-content secondary-page"><div className="page-heading"><div><div className="eyebrow"><Settings2 size={13} /> PREFERÊNCIAS DO ESTÚDIO</div><h1>Configurações <span>gerais.</span></h1><p>Gerencie o modelo padrão e entenda como seus dados são tratados.</p></div></div>
        <div className="settings-layout"><section className="panel"><div className="panel-heading"><div className="panel-title"><div className="summary-icon"><Sparkles size={17} /></div><div><h2>Modelos de inteligência artificial</h2><p>Escolha o motor utilizado nas próximas gerações.</p></div></div></div>
          <div className="ai-model-list">{MODEL_OPTIONS.map(m => <button key={m.id} className={`ai-model-option ${providerModel === m.id ? "active" : ""}`} onClick={() => { setProviderModel(m.id);  }}><div className="ai-model-icon"><Aperture size={20} /></div><div><strong>{m.name}</strong><span>{m.note}</span></div><small>{m.tag}</small>{providerModel === m.id && <Check size={17} />}</button>)}</div>
          <div className="settings-note"><LockKeyhole size={16} /><div><strong>Configuração da chave de API</strong><p>A chave do Google Gemini é configurada no servidor, no arquivo <code>.env.local</code>. Ela não deve ser inserida nesta tela nem enviada ao navegador.</p></div></div>
        </section><section className="panel"><div className="panel-heading"><div className="panel-title"><div className="summary-icon"><ShieldCheck size={17} /></div><div><h2>Privacidade & armazenamento</h2><p>Como os dados desta versão são guardados.</p></div></div></div>
          <div className="privacy-row"><div><strong>Perfis e imagens</strong><span>Salvos no IndexedDB do navegador deste aparelho.</span></div><span className="privacy-badge">LOCAL</span></div><div className="privacy-row"><div><strong>Chave da API</strong><span>Usada somente pelo endpoint no servidor.</span></div><span className="privacy-badge secure">PROTEGIDA</span></div><div className="privacy-row"><div><strong>Sincronização entre aparelhos</strong><span>Não habilitada nesta versão local.</span></div><span className="privacy-badge">INDISPONÍVEL</span></div>
          <div className="settings-note"><CircleHelp size={16} /><div><strong>Antes de publicar</strong><p>Configure limites de uso, autenticação e armazenamento remoto se o site for compartilhado com outras pessoas. Veja o README para as instruções.</p></div></div>
        </section></div>
      </div>}

      <footer className="app-footer"><span>STUDIO MODEL AI <b>·</b> Feito para criar</span><span>Imagens geradas por IA podem variar em identidade e detalhes.</span></footer>
    </section>
  </main>;
}
