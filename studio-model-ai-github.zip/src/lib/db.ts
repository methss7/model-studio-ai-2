import type { GalleryItem, ModelProfile } from "./types";

const DB_NAME = "studio-model-ai";
const DB_VERSION = 1;
const MODEL_STORE = "models";
const GALLERY_STORE = "gallery";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") return reject(new Error("Armazenamento local indisponível neste navegador."));
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(MODEL_STORE)) db.createObjectStore(MODEL_STORE, { keyPath: "id" });
      if (!db.objectStoreNames.contains(GALLERY_STORE)) db.createObjectStore(GALLERY_STORE, { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Não foi possível abrir o armazenamento."));
  });
}

async function request<T>(storeName: string, mode: IDBTransactionMode, action: (store: IDBObjectStore) => IDBRequest): Promise<T> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, mode);
    const req = action(tx.objectStore(storeName));
    req.onsuccess = () => resolve(req.result as T);
    req.onerror = () => reject(req.error ?? new Error("Falha no armazenamento local."));
    tx.oncomplete = () => db.close();
    tx.onerror = () => { db.close(); reject(tx.error ?? new Error("Falha na transação local.")); };
  });
}

export const saveModel = (model: ModelProfile) => request<IDBValidKey>(MODEL_STORE, "readwrite", s => s.put(model));
export const getModels = () => request<ModelProfile[]>(MODEL_STORE, "readonly", s => s.getAll());
export const deleteModel = (id: string) => request<undefined>(MODEL_STORE, "readwrite", s => s.delete(id));
export const saveGalleryItem = (item: GalleryItem) => request<IDBValidKey>(GALLERY_STORE, "readwrite", s => s.put(item));
export const getGallery = () => request<GalleryItem[]>(GALLERY_STORE, "readonly", s => s.getAll());
export const deleteGalleryItem = (id: string) => request<undefined>(GALLERY_STORE, "readwrite", s => s.delete(id));
