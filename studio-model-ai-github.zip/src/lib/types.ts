export type RefKind = "model" | "pose" | "outfit" | "scene";
export type ImageReference = { id: string; kind: RefKind; name: string; dataUrl: string; mimeType: string };
export type ModelProfile = { id: string; name: string; description: string; references: ImageReference[]; createdAt: number; updatedAt: number };
export type GalleryItem = { id: string; image: string; mimeType: string; prompt: string; modelName: string; modelId: string; providerModel: string; createdAt: number; ratio: string; resolution: string };
export type StudioSettings = { providerModel: string; ratio: string; resolution: string; style: string; lighting: string; framing: string; cameraAngle: string; depth: string };
