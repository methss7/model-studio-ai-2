STUDIO MODEL AI — INSTALAÇÃO PELO ANDROID

AVISO DE SEGURANÇA
Não reutilize a chave que você enviou na conversa. Revogue/rotacione essa credencial no serviço que a emitiu. Para Gemini, crie uma chave nova em https://aistudio.google.com/apikey. O prefixo da chave compartilhada não é o formato usual de uma chave Gemini (AIza...). Nunca envie chaves, senhas ou tokens em conversas.

IMPORTANTE
O projeto é um site Next.js, não um APK. Para ficar disponível no Chrome do Android, precisa ser publicado em uma hospedagem.

PUBLICAÇÃO
1. Baixe e extraia o ZIP.
2. Entre em https://github.com e crie um repositório PRIVADO.
3. Envie o conteúdo da pasta studio-model-ai para esse repositório. Não envie .env.local nem qualquer arquivo com segredo.
4. Entre em https://vercel.com e importe o repositório privado.
5. Nas configurações do projeto na Vercel, abra Environment Variables.
6. Crie GEMINI_API_KEY e cole a NOVA chave Gemini criada no AI Studio.
7. (Opcional) Crie MAX_REFERENCE_MB com valor 18.
8. Faça o Deploy. Depois abra a URL gerada no Chrome do Android.

LIMITAÇÃO DE ACESSO
A publicação exige que você entre nas suas próprias contas GitHub e Vercel e autorize o acesso. Não compartilhe senha, token de acesso ou chave de API comigo.

TESTE LOCAL
Para executar localmente, é necessário computador/servidor com Node.js 22 ou superior: npm install; copie .env.example para .env.local; configure GEMINI_API_KEY; execute npm run dev.

DADOS
Nesta versão, modelos e galeria ficam no armazenamento local do navegador. Não há login nem sincronização entre aparelhos.
