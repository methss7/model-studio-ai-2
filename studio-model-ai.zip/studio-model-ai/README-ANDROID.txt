PARA USAR NO ANDROID

O projeto é um site Next.js. Ele não roda diretamente como um APK comum: precisa ficar hospedado em um serviço como Vercel ou executado em um computador/servidor com Node.js.

Fluxo recomendado pelo celular:
1. Baixe o ZIP e guarde no aparelho.
2. Abra https://github.com e crie um repositório privado.
3. Envie os arquivos do ZIP para o repositório (pode usar o site do GitHub no Chrome).
4. Abra https://vercel.com e importe esse repositório.
5. Nas variáveis de ambiente da Vercel, cadastre GEMINI_API_KEY com a chave criada em https://aistudio.google.com/apikey.
6. Publique. Abra a URL do site no Chrome Android.

Você também pode baixar o ZIP e enviar para um computador para executar npm install e npm run dev. Veja README.md para detalhes.
